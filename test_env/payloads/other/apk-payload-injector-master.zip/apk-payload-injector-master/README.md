# apk-payload-injector
POC for injecting Metasploit payloads on arbitrary APKs
