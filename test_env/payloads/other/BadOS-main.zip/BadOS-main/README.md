# BadOS
Fun BadUSB scripts for iOS! Tested with BadBT Made for the Flipper Zero!

ㅤ

More Custom script TOOLs for iOS, instead of those boring basic scripts like opeing a website then inserts a URL. 
ㅤ

But with some of these scripts you can get more keyboard access for iPad and iPhone! 

ㅤ

such as :

ㅤ

The "Caught in 4k" Script

Description : Opens up a sepcific link and screenshots what your looking at :)

ㅤ

The "RLSWIPER" Script

Description : Goes through the device and check out everything (is not perfect)

ㅤ

The "My Last Picture" Script

Description : Crashes the screen with a bunch of pictures (may reboots itself, may depend on the device) USE WISELY!

ㅤ

The "Not MY TABS" Script

Description : DELTES 100+ TABS USE WISELY!

ㅤ

The "Tab Flooder" Script

Description : SPAMS OVER 100+ TABS USE WISELY!

ㅤ

The "Text Me" Script

Description : Opens up Messages and types to whoever was last texted

ㅤㅤ

The "Tab Viewer" Script

Description : goes through your tabs 1-9 and check them out (May need to adjust Delay depending on internet speed)
ㅤ
ㅤ

(REMINDER THESE ARE NOT PERFECT SCRIPTS MAY NEED TO REDO SOME FOR THEM TO WORK)




ㅤ

If YOU make some custom Scripts from BadOS id like to know, cause I would love to add more BadOS scripts based off the Flipper Community! 
if you can my discord is "desktopsetup"
Im also on the offical FlipperZero Discord server where if you want id like to see some.
