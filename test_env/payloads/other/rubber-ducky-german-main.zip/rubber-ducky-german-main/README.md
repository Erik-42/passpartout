# German Rubber Ducky encoder
German HTML/JS based encoder for [Rubber Ducky](https://shop.hak5.org/products/usb-rubber-ducky-deluxe). Go to https://schlomo.github.io/rubber-ducky-german/ to use it.

I took the HTML file found at https://forums.hak5.org/topic/43834-release-html-duck-encoder/ and replaced the built-in US keyboard encoding with the German keyboard encoding found at https://github.com/hak5/bashbunny-payloads/tree/master/languages

I couldn't find a license, hope that this is OK for the original author.

Please consider my contribution to be public domain, no warranties whatsoever.

# Rubber Ducky Encoder mit Unterstützung für Deutsches Tastaturlayout

Die Version des Encoders hier erzeugt Rubber Ducky Dateien, die mit einem Deutschen Tastaturlayout funktionieren.
