# Generator
Evade AV with obfuscated payloads


# Installation

must install `dotnet` prior to running the script with `net45` 

# Running

`./generator.py -ip <Your-IP> -port <Your-PORT> -key <XOR key for example 0xff>`

Should generate `payload.exe`
