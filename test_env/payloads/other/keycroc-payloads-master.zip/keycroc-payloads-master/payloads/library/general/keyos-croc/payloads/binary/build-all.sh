GOOS=linux go build -o lin
GOOS=darwin go build -o mac
GOOS=windows go build -o win.exe
