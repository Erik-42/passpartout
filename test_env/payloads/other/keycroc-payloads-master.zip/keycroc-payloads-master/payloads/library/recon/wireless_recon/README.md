# Wireless Recon

- Title:            Wireless Recon
- Author:           TW-D
- Version:          1.0
- Target:           Any
- Category:         Recon
- Attackmode:       HID

## Description

Gets useful information about nearby WiFi access points
with the "Key Croc".

## Configuration

From "wireless-recon_payload.txt" change the values of the following variable :
```

######## SETUP ########

LED SETUP

export DUCKY_LANG=us


```

## Trigger

>
> __wireless-recon
>