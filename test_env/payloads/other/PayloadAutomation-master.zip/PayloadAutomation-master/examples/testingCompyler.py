#!/usr/local/bin/python3
from payload_automation.compyler import msbuildCSharp

msbuildCSharp("solution.sln")