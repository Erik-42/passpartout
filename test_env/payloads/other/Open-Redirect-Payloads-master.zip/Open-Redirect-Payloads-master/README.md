<a href="https://www.buymeacoffee.com/cujanovic" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>

[I'm grateful for the support received by Tuta](https://tuta.com/)

# Open Redirect Payloads
Payloads from BB reports for Open Redirect

***

### make-payloads.sh - replace www.whitelisteddomain.tld with a specific whitelisted domain in your test case

```
./make-payloads.sh www.whitelisteddomain.pw

./make-payloads.sh www.google.com

./make-payloads.sh app.domain.com
```

***
