$logs = @(
"V1.0       Initial Release       7-July-2022",
"V1.1       Optimized Update functionality and added logging       9-July-2022",
"V1.2       Filtered upload setting to only allow ps1 files       11-July-2022",
"V1.3       Made the version a global variable       12-July-2022",
"V1.4       Update screen shows new changes       13-July-2022",
"V1.5       Added build payload tab to menu       14-July-2022",
"V1.6       Made base64 encoding of payload an option instead of the default       16-July-2022"
)
