- Install following packages : ``` curl ```
- Refer to this payload to install package https://github.com/julesbozouklian/shark_jack_payload/blob/main/payload/util/install_package.sh
- Or SSH to the Shark jack and use following command : ``` opkg install curl ```

- Create a Teams canal
- Add the application Incoming Webhook
- Get your WebHook URL
