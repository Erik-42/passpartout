<a href="https://www.buymeacoffee.com/cujanovic" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" style="height: 60px !important;width: 217px !important;" ></a>

[I'm grateful for the support received by Tuta](https://tuta.com/)

# Markdown XSS Payloads
XSS payloads for exploiting Markdown syntax
