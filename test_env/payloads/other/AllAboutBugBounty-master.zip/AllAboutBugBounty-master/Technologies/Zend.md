# Zend Common Bugs

## Introduction
What would you do if you came across a website that uses Zend?

## How to Detect
`-`

1. Finding config files
```
https://target.com/application/configs/application.ini
https://target.com/admin/configs/application.ini
```