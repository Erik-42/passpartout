# OMG-Payloads
Payloads for the O.MG cables and accessories. Might work for Rubber Ducky too!
