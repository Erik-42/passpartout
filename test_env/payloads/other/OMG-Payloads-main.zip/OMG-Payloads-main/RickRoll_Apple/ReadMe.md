Title: RickRoll Apple<br>
Author:	Kalani / UberGuidoZ<br>
Original ASCII found online, cleaned it up and made it dance a bit.<br>

Description: Opens Safari, enters YouTube link, goes full screen.<br>
Notes: Kalani wrote the original code, just modded to a Rick Roll!<br>
Target:	Apple iOS (iPhone, iPad)<br>
Version:	1.0<br>
Category:	Prank<br>
Source: https://github.com/UberGuidoZ/OMG-Payloads
