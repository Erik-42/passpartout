Title: Rick Rolling Forever
Author:	UberGuidoZ
Inspired by burnttoast when assisting with a LONG script (over 2,750 lines!)

Description: Creates a batch file that opens a Rick Roll every 5 mins in default browser
Notes: Creates batch file, starts batch file, minimizes the window
Target:	Windows but fairly easily modified to work on any OS with a browser
Version:	1.3
Category:	Prank
Source: https://github.com/UberGuidoZ/OMG-Payloads