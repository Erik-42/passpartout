# Shortcut-Payload-Generator
- Exploiting Powershell to make ShortCut Payloads [fud].
- There is too much of awsome tricks there , u can make it better ^_^. 
- For Ex : Killing tcpview , taskmanager ..etc while downloading.
- Set hidden attribs to the malware after downloading....etc
- G00d by3. 
- ./9aylas 


![alt text](screenshot_lnkkisser.bmp "huh")
![alt text](screenshot_lnkkisser_tcpview.bmp "hah")

>EOF
