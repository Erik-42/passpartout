## 1.0.2

- Added `blockAll` access control function

## 1.0.1

- Added jsdoc documentation
- Added `allowUser` alias for `allowAnyUser`, because in some situations the name `allowAnyUser` might be confusing if used with a filter
- Fixed generic type constraint on `allowPublished` by making `_status` optional

## 1.0.0

- Active where clauses

## 0.2.0

- Added basic and composite access functions

## 0.1.0

- Initial version
