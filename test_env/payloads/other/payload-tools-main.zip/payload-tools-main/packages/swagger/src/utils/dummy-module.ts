// dummy module to prevent webpack from trying to build this package in the admin build
export default {};
