## 1.4.0

- Support for examples of collections and globals

## 1.3.1

- Fix issue with import of `defineEndpoint` in webpack

## 1.3.0

- Support for custom endpoint documentation of payload-openapi

## 1.2.1

- Adds fallback document if openapi document generation fails

## 1.2.0

- Alligned versioning with payload-openapi

## 1.0.0

- Uses `payload-openapi` version 1, whch has a validated schema with full payload endpoint coverage

## 0.5.0

- bulk endpoints (if payload version >=1.6.24)

## 0.4.0

- all endpoints included

## 0.3.0

- moved openapi document creation into separate `payload-openapi` package

## 0.2.0

- dropped server extension in favor of plugin

## 0.1.0

- Added custom endpoints
- Refactored `initSwagger` parameters

## 0.0.1

- Initial version
