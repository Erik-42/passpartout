## 1.4.0

- Ensure payload-openapi version >=1.4.0 is used

## 1.2.0

- Alligned versioning with payload-openapi

## 1.0.1

- Updated readme

## 1.0.0

- Published first major version (no changes)

## 0.1.2

- Payload as dependency instead of peer, to allow usage without prior installation

## 0.1.1

- Fixed swc dependency

## 0.1.0

- Initial beta version
