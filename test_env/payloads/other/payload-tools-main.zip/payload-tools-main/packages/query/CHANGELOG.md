## 1.0.1

- Option to only exclude some fields with a `Select`, but keep the rest.

## 1.0.0

- Initial version
