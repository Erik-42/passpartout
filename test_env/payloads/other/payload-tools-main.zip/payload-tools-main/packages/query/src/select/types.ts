export type Select<T> = Partial<Record<keyof T, boolean>>;
