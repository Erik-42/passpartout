export { getDescription, getPlural, getSingular } from './get-description';
export { getSingularSchemaName, getPluralSchemaName } from './get-schema-name';
export { merge } from './merge';
export * from './version';
export * from './supported';
