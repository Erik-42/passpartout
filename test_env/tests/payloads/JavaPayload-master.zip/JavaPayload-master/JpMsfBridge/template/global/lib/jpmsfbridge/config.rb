module JpMsfBridge
	module Config
		Root = File.expand_path(File.dirname(__FILE__))
$$		ClassPath = '${globals.classPath}'
$$		JavaExecutable = '${globals.javaExecutable}'
	end
end