# Mona Lisa
- Author: Cribbit
- Version: 1.0
- Target: Windows
- Category: General

## Change Log
| Version | Changes         |
| ------- | --------------- |
| 1.0     | Initial release |

## Description
Opens notepad and displays an ascii art version of the Mona Lisa.
