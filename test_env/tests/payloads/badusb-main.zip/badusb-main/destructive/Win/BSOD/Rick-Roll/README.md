# Rick Roll BSOD
Literally copied from the super mario BSOD, just changed the vid.
