# quackberry https://github.com/fierceoj/quackberry

USB Rubber Ducky scripts targeting Raspberry Pi OS 


