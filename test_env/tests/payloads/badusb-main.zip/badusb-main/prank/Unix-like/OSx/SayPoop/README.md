# SayPoop by Augie Doebling

Original repo: https://github.com/AugieDoebling/SayPoop

Best way to prank your roommate

### Instructions to Run
1. Download folder (works best on a flash drive)
2. Double-click CLICK_TO_RUN.command

### Notes
1. Attempts to eject flash drive if folder is on flash drive.
2. Only works on Mac.
3. To edit command and frequency, edit the python code in install_cron.py.
4. Please use responsibly. Authors are not responsible for any uses of this script.

### Uninstall
1. Open Terminal
2. Run `crontab -r`
