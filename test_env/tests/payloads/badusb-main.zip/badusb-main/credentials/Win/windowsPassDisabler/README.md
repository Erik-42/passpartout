# windowsPassDisabler
https://github.com/tuconnaisyouknow/BadUSB_windowsPassDisabler
# Warning ⚠️
Everything in this repository is **strictly** for educational purposes. Notice **I am not responsible** for stolen data. **You are responsible** for your actions using developed script for **BadUSB**.
# About ℹ️
This script allows you to disable your victim's Windows password in a few seconds.
### NB n°1
You can customize the **delay** according to the speed of the computer in which you plug the **BadUSB**.
### NB n°2
When you plug the BadUSB in a PC you  have to wait for the caps lock to flash to unplug it.
# Getting Started ✔️
## Requirments
1. Have a **BadUSB**;

2. Install **Arduino software** [here](https://www.arduino.cc/en/software) (if you have a BadUSB based on Arduino);
## Install
1. Download this repository;
**Linux :**
```
git clone https://github.com/tuconnaisyouknow/BadUSB_windowsPassDisabler
cd BadUSB_windowsPassDisabler
```
**Windows :** Click on green button on right top of main page. Then click on "Download Zip" and extract zip file.

2. Put the .ino or .txt file in your BadUSB;

3. Find a victim and enjoy !
## Requirments for victim PC
* Turn off caps lock;
* Switch the keyboard layout to English;
