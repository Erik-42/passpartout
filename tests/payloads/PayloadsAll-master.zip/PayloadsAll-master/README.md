# Payloads All The Things

A list of useful payloads and bypasses for Web Application Security.
Feel free to improve with your payloads and techniques !
I :heart: pull requests :)

You can also contribute with a :beers: IRL or with `buymeacoffee.com`

[![Coffee](https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png)](https://www.buymeacoffee.com/andripwn)

Every section contains the following files, you can use the `_template_vuln` folder to create a new chapter:

- README.md - vulnerability description and how to exploit it
- Intruder - a set of files to give to Burp Intruder
- Images - pictures for the README.md
- Files - some files referenced in the README.md
