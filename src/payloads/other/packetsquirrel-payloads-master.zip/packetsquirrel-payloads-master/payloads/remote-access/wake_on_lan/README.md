# Wake-on-LAN

This payload generates a WoL (Wake-on-LAN) magic packet for the devices listed in the 
payload configuration.

Make sure to copy BOTH `payload` and `wol_python.py` to the SAME payload directory on
the Packet Squirrel!
