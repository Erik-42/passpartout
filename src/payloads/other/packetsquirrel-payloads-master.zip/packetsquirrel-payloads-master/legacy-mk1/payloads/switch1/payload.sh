#!/bin/bash
# 
# Title:	    Default Payload
# Description:  Sets the NETMODE to NAT, then sets the LED to ATTACK
# Author: 	    Hak5
# Version:	    1.0
# Category:     default
# Target: 	    Any
# Net Mode:	    NAT

NETMODE NAT
LED ATTACK
