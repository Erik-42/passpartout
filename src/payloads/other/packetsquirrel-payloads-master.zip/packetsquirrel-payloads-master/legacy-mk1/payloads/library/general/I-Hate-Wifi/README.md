|                 |                                                                                                    |
|:----------------|:---------------------------------------------------------------------------------------------------|
| **Title**	  |I Hate Wifi							       |
| **Description** | Deauths all wifi clients in the area with option to exclude your own .      |
 **Author**	  | TheDragonkeeper                                                   |
| **Version**	  | 1.0												      |
| **Category**	  | General											      |
| **Target** 	  | Any												      |

| Meaning   | Color             | Description                 |
|:----------|:-----------------:|:----------------------------|
| Waiting:  | Blinking yellow       | Waiting on network - getting requirements   |  
| Failed:  | Flashing Red       | Failed to get package      |
| Scanning:  | Green       | Scanning for Aps      |
| Attacking:   | Red      | Deauthing targets   |
| Done:   | Blue      | Sleeping   |

| Requires   |
|:----------|
| Aircrack-ng  |
| usb wifi dongle |
| Fw 1.1 + |

| Options | Line | Result  |
|:----------|:----------|:----------|
| YOUR_AP_MAC='' |   37  |Add your mac address to exclude your AP from attack |
