# ngrep payload
Credits: Hak5Darren, Sebkinne
Small Edit: SebSeifert

# Description

Does packet sniffing stuff
If the Button is pressed you have x seconds to push the button one more time. If pressed the payload ends and cleans up. Else it keeps running.

## Options
BUTTON_WAIT = The seconds you can wait until the button must be pressed to end the payload.

