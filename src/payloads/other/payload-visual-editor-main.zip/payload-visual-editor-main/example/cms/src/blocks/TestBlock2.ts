import { Block } from "payload/types";

export const TestBlock2: Block = {
    slug: "testBlock2",
    fields: [
        { name: "number1", type: "number" },
        { name: "number2", type: "number" },
    ],
};
