# Mac_Exfil for the BashBunny

* Author: Carey Balboa - Mac Help Nashville, Inc. with assistance from corydon76 props to Nashville 2600
* Version: Version 1.0
* Target: macOS

## Description

A payload that Exfiltrates Word, Excel & PDF files from logged in users Documents and Desktop folders


## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Purple             | Executing Payload                            |
| Green              | Successfully grabbed files                   |
| Red                | Did not get files                            |
