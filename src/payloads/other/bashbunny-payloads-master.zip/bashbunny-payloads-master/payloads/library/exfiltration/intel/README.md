# intel(intelligence)

## About:
* Title: intel
* Description: intel(intelligence) payload collects detailed information of victims machine.
* AUTHOR: drapl0n
* Version: 1.0
* Category: Exfiltration
* Target: GNU/Linux
* Attackmodes: HID, Storage

## intel(intelligence) payload collects detailed information of victims machine.


### Workflow:
1. Prevent storing history.
2. Fetching BashBunny's block device.
3. Mounting BashBunny.
4. Transfering payload script and executing it.
5. Deleting script from victims system.
6. Unmounting BashBunny.

#### Support me if you like my work:
* https://twitter.com/drapl0n
