# FTP Exfiltrator for Bash Bunny

* Author: Nutt
* Version: Version 1.0
* Target: Windows

## Description

Exfiltrates files from the users Documents folder
FTP's all files/folders to a specified FTP site named by the victim hostname.
Powershell FTP script will stay running after BashBunny is unplugged, once light turns green unplug and check FTP site.

## Configuration

Edit 1.ps1 to specify FTP site, username and password

## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Purple			 | Setup								        |
| Red                | Failed - Not working yet                     |
| Green              | Attack Complete                              |

## Discussion
[Hak5 Forum Thread](https://forums.hak5.org/index.php?/topic/40492-payload-ftp-exfiltrator/ "Hak5 Forum Thread")
