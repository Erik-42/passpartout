# HiveNightmare

Leverages CVE-2021–36934 to get SAM/SYSTEM/SECURITY hives.

## Options
### TRIES
> The amount of shadowcopies to search for the SAM/SYSTEM/SECURITY hives.
