# StickyBunny
* Author:	Squibs
* Version:	0.1
* Target:	Windows
* Time:		19s

## Description

Changes the sticky keys executeable to a CMD executatble allowing CMD to be opened at login page.

## Configuration

None.

## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Blue (blinking)    | Setting up                                   |
| Purple (blinking)  | Running Attack		                        |
| Green  (solid)     | Complete							            |
