#!/bin/bash

# Wake up and do something productive here instead...
sleep 10

# boom!!
firefox "http://hak5.org"
