#!/bin/bash
sleep 5
poweroff