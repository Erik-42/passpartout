# ALTCODE DEMO

* Author: Hak5Darren
* Props: Crackruckles
* Demo: Hak5 episode 2506
* Target: Windows 95+
* Category: General

## Description

Demonstrates usage of QUACK ALTCODE by typing Hak5 ANSI art into command prompt

## STATUS

| LED               | Status                                 |
| ----------------- | -------------------------------------- |
| SETUP             | Setting attack mode                    |
| ATACK             | Injecting keystrokes                   |
