#!/bin/sh
wget http://s3.amazonaws.com/alexa-static/top-1m.csv.zip