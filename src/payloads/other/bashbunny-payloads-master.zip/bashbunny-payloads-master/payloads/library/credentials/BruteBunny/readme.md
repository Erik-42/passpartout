# BruteBunny

* Author: Decoy
* Version: Version 1.0
* Target: Windows

## Description

I would say that some (most) people don't realize that devices they connect to their networks usually have
weak default usernames and passwords. The Brute Bunny will exploit that in hopes of finding some poor sap
who didn't change their admin password for their device, and educate them accordingly.

## Configuration

Modify the variables in brutebunny.ps1 to change the default IP/Port for this attack. Feel free to use your
own wordlists as well; however you will need to adjust some of the sleep times accordingly depending on the
length of time your list will take to go through.

## Notes

This was designed and tested on a Netgear Nighthawk Router, and an Arris Xfinity Modem/Router combo; however
I don't see why it couldn't be used for any internet connected device that uses basic http authentication.
And please... Don't feed the bunnies.

## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Purple             | Reticulating splines                         |
| White (blinking)   | Waiting for Storage                          |
| Blue (blinking)    | Brute Bunny being a Brute Bunny              |
| Green              | Hopefully no bunny babies                    |

## Discussion
Not yet
