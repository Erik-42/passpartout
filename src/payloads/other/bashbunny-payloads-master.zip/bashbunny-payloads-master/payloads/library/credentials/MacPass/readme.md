# Mac Password Grabber for the BashBunny

* Author: Overtimedev
* Version: Version 1.0
* Target: OSX

## Description

Steals Mac Passwords using laZagne.py then stashes them in /loot/MacPass 



1. put get-pip.py, laZagne.py and requirements.txt in the root folder of the bunny 

2. unzip lazagne.zip into the root folder of the bunny

3. Replace PASSWORD, with your vicims mac computer password in payload.txt


## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Amber              | Executin Payload                             |
| Green              | Attack Finished                              |
