#!/bin/bash
loc=$HOME/.config/bunnyLogger
rm -rf $loc
sudo rm /usr/local/bin/bunnyLoggerMgr
