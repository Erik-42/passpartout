**Title: SessionBunny**

Author: 0i41E
(Credit for SessionGopher: Brandon Arvanaghi)

Version: 1.0

**Instruction:**

This payload will run the famous SessionGopher script, which was only slightly modified. Searches for PuTTY, WinSCP, and Remote Desktop saved sessions, decrypts saved passwords for WinSCP,
Extracts FileZilla, SuperPuTTY's saved session information in the sitemanager.xml file and decodes saved passwords.
After you recieve the information, save the items you are interested in simply on your BashBunny.

#

**Instruction:**

Place SessionBunny.ps1 in the same payload switch-folder as your payload.txt
#
Plug in BashBunny.
Wait for the script to finish and decide what you wanna do with the information gathered
![alt text](https://github.com/0i41E/bashbunny-payloads/blob/master/payloads/library/credentials/SessionBunny/censorepic.png)
