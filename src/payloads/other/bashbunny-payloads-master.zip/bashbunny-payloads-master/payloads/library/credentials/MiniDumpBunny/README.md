**Title: MiniDumpBunny**

Author: 0i41E

Version: 1.0

What is MiniDumpBunny?
#
*MiniDumpBunny uses Powersploits Out-MiniDump script to dump lsass. The script was rewritten, adapted for BashBunny usage and obfuscated in multiple ways to evade Antivirus.*
#

**Instruction:**

Plug in your BashBunny equipped with the obfuscated MiniBunny.bat file, wait a few seconds, go away.
#
Exfiltrate the .dmp file and read it with Mimikatz.
![alt text](https://github.com/0i41E/bashbunny-payloads/blob/master/payloads/library/credentials/MiniDumpBunny/mimi.png)