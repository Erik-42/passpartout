# Windows Wifi Credentials Grabber

* Author: Silvian
* Version: Version 1.0
* Target: Windows 7 (not tested on Windows 8 and above)

## Description

This is a simple Wifi password grabber tested and working for Windows 7
However this has not been tested on Windows 8 and above and any suggestions and
improvements are greatly welcomed. Powershell scripting isn't higest skill so
I'm sure I'll have much to learn from sharing this code with everyone. :)

## Dependencies

Everything is included - no extra dependencies needed to run this payload.

## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Purple             | Starts the attack payload                    |
| Green              | successful execution                         |
| Red                | failure to load dependency ducky script      |
