**Title: HashDumpBunny**

Author: 0i41E

Version: 1.0

**Instruction:**

This payload will run an obfuscated script to dump user hashes. If you don't trust this obfuscated .bat file, you should run it within a save space first - which should be best practice anyways ;-)

#
**!Depending on your Windows version, this might not work as intended!**
#
**Instruction:**

Place BunnyDump.bat in the same payload switch-folder as your payload.txt
#
Plug in BashBunny.
Exfiltrate the out.txt file and try to crack the hashes.
![alt text](https://github.com/0i41E/bashbunny-payloads/blob/master/payloads/library/credentials/HashDumpBunny/censoredhash.png)
