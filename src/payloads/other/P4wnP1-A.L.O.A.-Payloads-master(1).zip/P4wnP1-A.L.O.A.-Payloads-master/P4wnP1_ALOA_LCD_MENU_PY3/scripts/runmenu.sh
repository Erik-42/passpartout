#!/bin/sh 
python3 /root/BeBoXGui/check_ssh.py &


