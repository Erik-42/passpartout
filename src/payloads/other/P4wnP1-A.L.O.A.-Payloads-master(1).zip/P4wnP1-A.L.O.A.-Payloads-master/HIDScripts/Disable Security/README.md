# Description

Disable Windows Security (Windows Defender)

Microsoft has introduced a feature called ["Tamper Protection"](https://support.microsoft.com/en-us/help/4490103/windows-10-prevent-changes-to-security-settings-with-tamper-protection) which prevents disabling windows security features using powershell.

So...Let's use the keyboard to disable it ;)

