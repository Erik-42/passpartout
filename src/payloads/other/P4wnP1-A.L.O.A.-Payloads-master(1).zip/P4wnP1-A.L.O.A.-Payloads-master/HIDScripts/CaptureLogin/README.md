# Description

Creates a fake windows authentication prompt for phishing user domain credentials
Generates a get request with an encoded base64 string.

Based on "Powershell Popups + Capture" by Mubix

[https://malicious.link/post/2015/powershell-popups-and-capture/](https://malicious.link/post/2015/powershell-popups-and-capture/)


# DEMO

![](https://raw.githubusercontent.com/NightRang3r/P4wnP1-A.L.O.A.-Payloads/master/HIDScripts/CaptureLogin/Ws281QH2fu.gif)

