## Payloads
### Windows

* [CD-Tray Auto Eject](/Windows/CD-Tray%20Auto%20Eject)
* [Change Desktop Background](/Windows/Change%20Desktop%20Background)
* [Dissble Internet](/Windows/Disable%20Internet)
* [Dissable Windows Defeneder](/Windows/Dissable%20Windows%20Defeneder)
* [Epic Sax Powershell](/Windows/Epic%20Sax%20Powershell)
* [Epic Tree Hack](/Windows/Epic%20Tree%20Hack)
* [Fake Windows 10 Update](/Windows/Fake%20Windows%2010%20Update)
* [HALL 9000](/Windows/HALL%209000)
* [Network Creds Exfiltration (FTP)](/Windows/Network%20Creds%20Exfiltration%20(FTP))
* [Annoying Random Fact](/Windows/Random%20Fact)
* [Rick Roll No Powershell](/Windows/Rick%20Roll%20No%20Powershell)
* [Speech Synthesizer](/Windows/Speech%20Synthesizer)
* [Steal Wifi Passwords Via Serial](/Windows/Steal%20Wifi%20Passwords%20Via%20Serial)
* [Swap Mouse Button](/Windows/Swap%20Mouse%20Button)
* [Turn Up Volume No Powershell](/Windows/Turn%20Up%20Volume)
* [Turn Up Volume Powershell](/Windows/Turn%20Up%20Volume%20Via%20Powerhell)
