# Alien Message From Computer

A script used to prank your friends with a script that simulate an Alien inside the computer.

**Category**: Prank

## Description

A script used to prank your friends with a script that simulate an Alien inside the computer.

Open a PowerShell, download the Python script and execute it. The Python script will simulate the Alien using the Python library pyttsx3.

## Getting Started

### Dependencies

* Internet Connection
* ExecutionPolicy Bypass
* Python

### Settings

* Nothing to setup, it is Plug-And-Play

### FAQs

- Why is the code in one line?
  - In Python if TAB errors are made then execution is blocked so to avoid writing so many DuckyScript STRING elements I wrote everything in one line separating each command by a semicolon. However, the code can be viewed entirely in the script.py file and edited as desired.

## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/github.png?raw=true width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/linkedin.png?raw=true width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>