# Full-Screen Banner Joke

A script used to prank your friends with full-screen banner.

**Category**: Prank

## Description

A script used to prank your friends with full-screen banner.

Open a PowerShell, download the Python script and execute it. The Python script will create a black full screen with a triggered prank phrase. 

## Getting Started

### Dependencies

* Internet Connection
* Python installed
* ExecutionPolicy Bypass

### Settings

- Setup your Python script link in the payload.txt file

## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/github.png?raw=true width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/linkedin.png?raw=true width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>