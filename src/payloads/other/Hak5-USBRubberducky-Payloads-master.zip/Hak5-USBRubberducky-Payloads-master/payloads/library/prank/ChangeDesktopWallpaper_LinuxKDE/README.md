# Change Desktop Wallpaper - Linux ✅

A script used to prank your friends changing their desktop wallpaper.

**Category**: Prank

## Description

A script used to prank your friends changing their desktop wallpaper.

Opens a shell, download the image, define the local image path, run a command KDE BASED that will replace the desktop wallpaper with the local image path, then delete the image downloaded, clear the history and close the shell.

## Getting Started

### Dependencies

* Internet Connection
* Linux KDE

### Settings

- Image link
- Local image path

## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/github.png?raw=true width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/linkedin.png?raw=true width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>