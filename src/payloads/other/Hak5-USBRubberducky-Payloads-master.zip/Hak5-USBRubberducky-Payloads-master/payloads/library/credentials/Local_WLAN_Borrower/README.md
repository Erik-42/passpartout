### Local_WLAN_Borrower
This script borrows the wifi passwords on the target system and puts them into a .txt file on the ducky.

# Setup
Firstly, download and place the _1.ps1_ script onto the root of your ducky. Then, you will need to edit the inject.txt file accordingly:
On line 57, change "DUCKY" to the label of your USB. On line 59, change 1.ps1 to the name of the PS1 script on your ducky. 
Inside of the PS1 script, you will need to replace _DUCKY_ on line 2 with the label of your USB. 
