# Set An Arbitrary DNS (IPv4 version)

This script can be used to change the default DNS server in Windows 11.

**Category**: Execution

## Description

This script can be used to change the default DNS server in Windows 11.

The script open the settings, then go to network settings, then go to wi-fi settings, then go to hardware properties settings, the open the dns settings, then change to manual, then set the DNS server defined before, then save the settings changed and close the window.

- You must edit the DNS defining the IPv4 in the payload.txt file

```DuckyScript
REM DNS IPv4 like Cloudflare DNS 1.1.1.1
DEFINE DNS example
```

## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/github.png?raw=true width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/linkedin.png?raw=true width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>