# Stop A Single Process In Windows

This script can be used to quickly stop an active process on a windows machine.

**Category**: Execution

## Description

This script can be used to quickly stop an active process on a windows machine.

This script open the Task Manager app, then go to search bar, then write the process name that want to be stopped, open the right click mouse menu and click the end task option, then close the task manager app.

## Dependencies

* Nothing

## Settings

- Write the name of the process that you want to stop 
    
    `DEFINE PROCESS_NAME example`

## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/github.png?raw=true width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/linkedin.png?raw=true width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>