# Make Windows performant (but ugly and boring)

This script can be used to change some advanced Windows settings to make it as efficient as possible albeit losing some of the fluidity and beauty of the operating system.

This script is Plug-And-Play <3

**Category**: Execution

![](Make_Windows_performant_but_ugly_and_boring.gif)

## Description

This script can be used to change some advanced Windows settings to make it as efficient as possible albeit losing some of the fluidity and beauty of the operating system.

The script opens the Windows advanced settings via sysdm.cpl and accesses the advanced settings by changing the selected option for best performance and unchecking all possible features.

### Dependencies

* Nothing is needed, this script is Plug-And-Play <3

## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/github.png?raw=true width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/linkedin.png?raw=true width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>