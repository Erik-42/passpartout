# Uninstall Signal

A script used to uninstall signal-desktop app on Windows users.

**Category**: Execution

## Description

A script used to uninstall signal-desktop app on Windows users.

Open a PowerShell, stop the Signal proccess if it runs and then execute the uninstall file trhough general path.

## Dependencies

* Signal App installed (obviously LOL)
* ExecutionPolicy Bypass

## Settings

- Nothing to set, this payload is Plug-And-Play <3

## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/github.png?raw=true width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/linkedin.png?raw=true width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>