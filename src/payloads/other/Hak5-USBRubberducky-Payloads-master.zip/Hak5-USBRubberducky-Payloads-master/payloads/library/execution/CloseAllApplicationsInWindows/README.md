# Close All Applications - BADUSB ✅

A script used to close all target open applications.

🟢 **Plug-And-Play** 🟢

**Category**: Execution

## Description

A script used to close all target open applications.

Opens PowerShell hidden, download a Python script, execute it, remove Python script downloaded, delete powershell history.

## Getting Started

### Dependencies

* Internet Connection
* Windows 10,11

### Settings

- No settings - Plug-And-Play

## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/github.png?raw=true width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/linkedin.png?raw=true width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>