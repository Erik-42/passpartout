Title: Open Link<br>
Author:	mrproxy<br>

Description: Opens Spotlight, Prints the link, enters it.<br>
Target:	Apple iOS (iPhone, iPad)<br>
Version:	1.0<br>
Category:	Mobile-IOS<br>
Source: https://github.com/Mr-Proxy-source/BadUSB-Payloads<br>
