## 1 Script to Rule Them All

The purpose of this frankenstein mess is to use OS detection to run conditional code after, specific to the OS.

It differs from just combining the two extensions in very few ways, but there are slight improvement tweaks from my own testing (hence the new name to avoid conflicts) and more documentation on the process within.
