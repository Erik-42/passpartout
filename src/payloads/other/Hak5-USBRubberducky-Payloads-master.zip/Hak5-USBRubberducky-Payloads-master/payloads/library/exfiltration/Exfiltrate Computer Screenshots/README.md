# Exfiltrate Computer Screenshots

A script used to prank your friends exfiltrating some screenshots.

**Category**: Exfiltration

## Description

A script used to prank your friends exfiltrating some screenshots.

Open a PowerShell, download the Python script and execute it. The Python script will make some screenshot that will be sent, through the discord webhook, to you.

## Getting Started

### Dependencies

* Internet Connection
* Discord Webhook (or whatever you want for the exfiltration)
* ExecutionPolicy Bypass
* Python

### Executing program

* Plug in your device

### Settings

- Setup your Python script link in the payload.txt file
- Setup your Discord webhook link in the script.py file

## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/github.png?raw=true width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/linkedin.png?raw=true width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>