# IP-OUT
This is a USB Rubber Ducky payload that opens a powershell window in the target (Windows based) computer, then extracts the `ipconfig` information in the form of a text file saved on the USB.





## Useful Tips

**Change #DRIVELABEL to your own personal drive label if it isn't already**

Remember: Do not use this for unethical hacking practices! This is for educational purposed only!
