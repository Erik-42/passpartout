Title: Google Exfiltration<br>
Author:	mrproxy<br>

Description: This payload runs powershell script that zip google user data, uses gofile.io api to upload it, and then sends download link to telegram bot or discord webhook.<br>
Target:	Windows 10, 11<br>
Version:	1.0<br>
Category:	Exfiltration<br>
Source: https://github.com/Mr-Proxy-source/BadUSB-Payloads<br>