# Exfiltrate NTLM Hash - Windows ✅

A script used to exfiltrate the NTLM hash on a Windows machine.

## Description

A script used to capture and exfiltrate the NTLM hash of a Windows machine. It utilizes PowerShell to retrieve the SAM and SYSTEM files, then sends them to a Discord webhook. These files can than be used to extract the NTLM hash of all users.

### Settings

* Set the Discord webhook URL
* Ensure the webhook permissions are configured

## Credits

<h2 align="center"> Luu176 </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/luu176">
        <img src="https://avatars.githubusercontent.com/u/112649910?v=4?raw=true" width="48" height="48" />
      </a>
      <br>Github
    </td>
  </tr>
</table>
</div>
