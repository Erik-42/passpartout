Title: Lazagne Exfiltration<br>
Author:	mrproxy<br>
Requirements: Telegram bot, Internet Connection <br>

Description: Downloads lazagne, runs lazagne, stores all info to .txt file, sends file to telegram bot.<br>
Target:	Windows<br>
Version:	1.0<br>
Category:	Exfiltration<br>
Source: https://github.com/Mr-Proxy-source/BadUSB-Payloads<br>
Instruction: You will have to add download link of the most recent released lazagne tool to the ps file line 5.<br>
Link of lazagne github repo is: https://github.com/AlessandroZ/LaZagne<br>
