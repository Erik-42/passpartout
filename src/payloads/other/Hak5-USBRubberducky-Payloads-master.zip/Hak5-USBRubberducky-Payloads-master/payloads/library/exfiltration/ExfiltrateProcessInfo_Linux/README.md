 
# Exfiltrate Process Info - Linux ✅

A script used to exfiltrate the process info on a Linux machine.

**Category**: Exfiltration

## Description

A script used to exfiltrate the process info on a Linux machine.

Opens a shell, get the process info, set the Discord webhook configuration, send it to the discord webhook, erase traces.

## Getting Started

### Dependencies

* Internet Connection
* Discord Webhook

### Settings

* Set the Discord Webhook configuration

## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/github.png?raw=true width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/linkedin.png?raw=true width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>