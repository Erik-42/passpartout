# Exfiltrate Linux Content With Dropbox - BADUSB ✅

A script used to take folder content on Linux Systems.

**Category**: Exfiltration, Execution

[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Faleff-github%2Fmy-flipper-shits&count_bg=%233C3C3C&title_bg=%233C3C3C&icon=linux.svg&icon_color=%23FFFFFF&title=views&edge_flat=false)](https://github.com/aleff-github/my-flipper-shits)

## Description

A script used to take folder content on Linux Systems.

Opens a shel, zip all zippable (R permission) content of the folder, send the zip into the dropbox folder, delete shell history.

## Getting Started

### Dependencies

* Internet Connection
* Linux System
* * Terminal that can be opened by the shortcommand CTRL-ALT t
* DropBox Account for the access token

### Executing program

* Plug in your device

### Settings

* Set your dropbox access token
* Set the folder path interessed (i.e. /Documents)
* Change (if you think that it is necessary) the delay of the zipping operation

## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/github.png?raw=true width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/linkedin.png?raw=true width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>