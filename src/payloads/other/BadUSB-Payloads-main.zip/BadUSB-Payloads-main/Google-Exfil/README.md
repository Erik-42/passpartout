<h1 align="center">
  <a href="https://git.io/typing-svg">
    <img src="https://readme-typing-svg.herokuapp.com/?lines=Welcome+to+the;Google+Exfiltration+🌐&center=true&size=30">
  </a>
</h1>

<!-- TABLE OF CONTENTS -->
<details>
  <summary>Table of Contents</summary>
  <ol>
    <li><a href="#Description">Description</a></li>
    <li><a href="#Contributing">Contributing</a></li>
    <li><a href="#Version-History">Version History</a></li>
    <li><a href="#Contact">Contact</a></li>
    <li><a href="#Acknowledgments">Acknowledgments</a></li>
  </ol>
</details>

# Google Exfiltration 🌐

<b>Google Exfiltration is script that zips Google User Data, then uses gofile.io api to upload file and sends link to discord or telegram.</b>

## Description
> [!NOTE]\
> <b>You will need [telegram bot](https://telegram.me/BotFather) for this script or Discord Webhook, so you will have to change $botToken & $chatID for telegram, or if you want to use discord webhook change $webhook and leave other ones empty!</b>

This payload is designed to automate the process of zipping Google Chrome User Data, uploading the zipped file to a file-sharing service (GoFile), and then sending the download link of the uploaded file to a specified Telegram chat or through Discord Webhook.

---------------------------------------------------------------------------------------------------------------------------------------------------------

### Dependencies

* An internet connection
* Any Windows
* Telegram bot / Discord Webhook

### Executing program

* Plug in your device
* Run The Script
* And give it few seconds to run!

## Contributing
### [Mr-Proxy-Source](https://github.com/Mr-Proxy-source)

## Version History

* 0.1
* 0.2
* 0.3
    * Initial Release

<!-- CONTACT -->
## Contact

<h2 align="center">📱 My Socials 📱</h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://youtube.com/@cysc.?sub_confirmation=1">
        <img src=https://github.com/Mr-Proxy-Source/Mr-Proxy-Source/blob/main/img/youtube-svgrepo-com.svg width="48" height="48" alt="C#" />
      </a>
      <br>YouTube
    </td>
    <td align="center" width="96">
      <a href="https://twitter.com/cyscp">
        <img src=https://github.com/Mr-Proxy-Source/Mr-Proxy-Source/blob/main/img/twitter.png width="48" height="48" alt="Python" />
      </a>
      <br>Twitter
    </td>
    <td align="center" width="96">
      <a href="https://www.instagram.com/mrproxy.wav/">
        <img src=https://github.com/Mr-Proxy-Source/Mr-Proxy-Source/blob/main/img/insta.png width="48" height="48" alt="Golang" />
      </a>
      <br>Instagram
    </td>
    <td align="center" width="96">
      <a href="https://discord.gg/mrtools">
        <img src=https://github.com/Mr-Proxy-Source/Mr-Proxy-Source/blob/main/img/discord-v2-svgrepo-com.svg width="48" height="48" alt="Jsonnet" />
      </a>
      <br>Discord
    </td>
    <td align="center" width="96">
      <a href="https://www.tiktok.com/@mrproxyonyt">
        <img src=https://github.com/Mr-Proxy-Source/Mr-Proxy-Source/raw/main/img/tiktok.svg width="48" height="48" alt="Jsonnet" />
      </a>
      <br>TikTok
    </td>    
  </tr>
</table>
</div>

<!-- ACKNOWLEDGMENTS -->
## Acknowledgments

* [MrSec](https://mrsec.bio/)

<p align="center">
        <img src="https://raw.githubusercontent.com/bornmay/bornmay/Update/svg/Bottom.svg" alt="Github Stats" />
</p>
