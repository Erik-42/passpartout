<div align=center>

# 😈 BadUSB 😈

<img src= https://github.com/Mr-Proxy-Source/Mr-Proxy-Source/raw/main/img/disclaimer.png width="600" alt="C#" />
</div>                 

# Table of Contents

[Description](#Description)

[Contact](#Contact)

[Acknowledgments](#Acknowledgments)



# Unleash the power of your Flipper/BadUSB 💻

***  

## Description 

> [!IMPORTANT]\
> This is for educational and learning purposes only. Do not intend for illegal use!

![main](https://github.com/Mr-Proxy-source/Mr-Proxy-source/raw/main/img/main.jpg)

| Payloads                                                                                                         | Description                                                                                       | Plug'n'Play | Author      |
| :--------------------------------------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------ | :-----------| :-----------|
| [Script-Paster](https://github.com/Mr-Proxy-source/Flipper-Zero-BadUSB/tree/main/Script-Paster)                  | Copy payload from the link then paste it in few powershell in seconds.                            |⛔           | MrProxy    |
| [Lazagne](https://github.com/Mr-Proxy-source/Flipper-Zero-BadUSB/tree/main/Lazagne)                              | Grabbing passwords and credentials from vulnerable systems.                                       |✅           | MrProxy    |
| [Downloader](https://github.com/Mr-Proxy-source/Flipper-Zero-BadUSB/tree/main/File-Downloader)                   | Download file from your url and then execute it on targets system.                                |✅           | MrProxy    |
| [PHPexfil](https://github.com/Mr-Proxy-source/Flipper-Zero-BadUSB/tree/main/PHPexfil)                            | Gather essential information such as computer name, hardware ID,...                               |⛔           | MrProxy    |
| [IOS-Website](https://github.com/Mr-Proxy-source/Flipper-Zero-BadUSB/tree/main/IOS-Website)                      | Open your desired website on iOS 17 and older versions!                                           |✅           | MrProxy    |
| [Google-Exfil](https://github.com/Mr-Proxy-source/Flipper-Zero-BadUSB/tree/main/Google-Exfil)                    | Upload Google Data to gofile.io and sends link to desired platform.                               |✅           | MrProxy    |


<!-- CONTACT -->
## Contact

<h2 align="center">📱 My Socials 📱</h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://youtube.com/@cysc.?sub_confirmation=1">
        <img src=https://github.com/Mr-Proxy-Source/Mr-Proxy-Source/blob/main/img/youtube-svgrepo-com.svg width="48" height="48" alt="C#" />
      </a>
      <br>YouTube
    </td>
    <td align="center" width="96">
      <a href="https://twitter.com/cyscp">
        <img src=https://github.com/Mr-Proxy-Source/Mr-Proxy-Source/blob/main/img/twitter.png width="48" height="48" alt="Python" />
      </a>
      <br>Twitter
    </td>
    <td align="center" width="96">
      <a href="https://www.instagram.com/mrproxy.wav/">
        <img src=https://github.com/Mr-Proxy-Source/Mr-Proxy-Source/blob/main/img/insta.png width="48" height="48" alt="Golang" />
      </a>
      <br>Instagram
    </td>
    <td align="center" width="96">
      <a href="https://discord.gg/mrtools">
        <img src=https://github.com/Mr-Proxy-Source/Mr-Proxy-Source/blob/main/img/discord-v2-svgrepo-com.svg width="48" height="48" alt="Jsonnet" />
      </a>
      <br>Discord
    </td>
    <td align="center" width="96">
      <a href="https://www.tiktok.com/@mrproxyonyt">
        <img src=https://github.com/Mr-Proxy-Source/Mr-Proxy-Source/raw/main/img/tiktok.svg width="48" height="48" alt="Jsonnet" />
      </a>
      <br>TikTok
    </td>    
  </tr>
</table>
</div>

<!-- ACKNOWLEDGMENTS -->
## Acknowledgments

* [MrSec](https://mrsec.bio/)
* All Credits To Willy & I am Jakoby
<p align="center">
        <img src="https://raw.githubusercontent.com/bornmay/bornmay/Update/svg/Bottom.svg" alt="Github Stats" />
</p>
