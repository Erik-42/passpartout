#!/bin/bash
cat /passwd > /tmp/flag
chmod 777 /tmp/flag