# Wordlists
This repository has various payload repositories that I need and use for discovery and recon against certain sites and targets. It will grow as more CMSes and platforms are enumerated. Feel free to contribute and add in pull requests.
