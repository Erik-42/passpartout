#ifndef _METERPRETER_SOURCE_REFLECTIVE_FREE_AND_EXIT_THREAD_H
#define _METERPRETER_SOURCE_REFLECTIVE_FREE_AND_EXIT_THREAD_H

#include <windows.h>

VOID ReflectiveFreeAndExitThread(HINSTANCE hAppInstance, DWORD dwExitCode);

#endif