/*!
* @file peinjector_bridge.h
*/
#ifndef _METERPRETER_SOURCE_EXTENSION_PEINJECTOR_BRIDGE_H
#define _METERPRETER_SOURCE_EXTENSION_PEINJECTOR_BRIDGE_H

DWORD request_peinjector_inject_shellcode(Remote *remote, Packet *packet);

#endif
#pragma once
