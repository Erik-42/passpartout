/*!
 * @file wmi.h
 * @brief Declarations for WMI request handlers.
 */
#ifndef _METERPRETER_SOURCE_EXTENSION_EXTAPI_WMI_H
#define _METERPRETER_SOURCE_EXTENSION_EXTAPI_WMI_H

DWORD request_wmi_query(Remote *remote, Packet *packet);

#endif
