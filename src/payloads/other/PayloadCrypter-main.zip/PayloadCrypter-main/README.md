# PayloadCrypter
make your scripts into payload, and undetectable from VT.
![image](https://github.com/EvilBytecode/PayloadCrypter/assets/151552809/d8e47232-2673-4894-9cca-dcc74e907aa6)

### Features:
- **Powershell to Batchfile Conversion:** Converts a PowerShell script into a Batch file.
- **Python Payload Crypter:** Obfuscates Python scripts with multiple layers of base64 encoding.
- **Powershell Payload Crypter:** Obfuscates PowerShell scripts with multiple layers of base64 encoding.
- **JavaScript Crypter:** Obfuscates JavaScript files using `eval(atob())` for multiple layers of encoding.
- **Batchfile Obfuscator:** Obfuscates Batch files by substituting characters with variable names.
- **Layers:** Of Obfuscation, can add how many you want.

### Languages Supported:
- **Powershell**
- **Python**
- **JavaScript**
- **Batch files (Windows Command Scripts)**

### READ :
- this was made to evade detections from static scanners, like virustotal and many more, thats why its only base64 + it was made for educational purposes.

### Output examples are in a OutputExamples directory.

### future
- xor since its way better lol
