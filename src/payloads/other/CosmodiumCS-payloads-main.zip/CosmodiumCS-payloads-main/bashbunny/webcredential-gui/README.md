# Web Credential Stealer
> Blue Cosmo

# Requirements
bashbunny, twinduck labled "P", or usb drive labled "P"

## Overview
steals web credentials from windows 10 computer

## Download:
```bash
svn checkout https://github.com/CosmodiumCS/payloads/trunk/bashbunny/webcredential-gui
```

## Setup
you must run the "P.exe" file in your microSD card before using this payload
- a "P.cfg" file should appear
