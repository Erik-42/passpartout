Opens a harmless website and pretend to hack into a GOV facility causing all sorts of chaos.
