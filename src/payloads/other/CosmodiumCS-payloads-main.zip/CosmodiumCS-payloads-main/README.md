# Payloads
> Blue Cosmo 

A repository containing my payloads for easy finding :)

## Hak5 Payload Libraries
- [Payloads.Hak5](https://payloads.hak5.org)
- [Bash Bunny](https://github.com/hak5/bashbunny-payloads)
- [Key Croc](https://github.com/hak5/keycroc-payloads)
- [Lan Turtle](https://github.com/hak5/lanturtle-modules)
- [O.MG Cable](https://github.com/hak5/omg-payloads)
- [Packet Squirrel](https://github.com/hak5/packetsquirrel-payloads)
- [Plunder Bug](https://github.com/hak5/plunderbug-scripts)
- [Shark Jack](https://github.com/hak5/sharkjack-payloads)
- [Signal Owl](https://github.com/hak5/signalowl-payloads)
- [USB RubberDucky](https://github.com/hak5/usbrubberducky-payloads)
- [Wi-Fi Pineapple](https://github.com/hak5/pineapple-modules)

## Default Hak5 Settings
```
Bash Bunny:
IP: 172.16.24.1
USER: root
PASS: hak5bunny

Lan Turtle:
IP: 172.16.84.1
USER: root
PASS: sh3llz

Packet Squirrel:
IP: 172.16.32.1
USER: root
PASS: hak5squirrel

Shark Jack:
IP: 172.16.24.1
USER: root
PASS: hak5shark

Wifi Pineapple:
IP: 172.16.42.1
USER: root
```
