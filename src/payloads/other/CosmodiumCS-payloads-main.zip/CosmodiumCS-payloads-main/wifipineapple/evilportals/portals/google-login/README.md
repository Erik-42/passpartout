Forked from https://github.com/couldbejake/google-login-remake
