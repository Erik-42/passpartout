# TREMOR
> Chris Taylor [Blue Cosmo] | DATE
---

```
ASCII PROJECT NAME OR IMAGE
```

## Overview:
TREMOR is a worm virus powered by the SharkJack. It will have the ability to spread a payload to different devices on the network.

## ROADMAP
- [x] Backdoor
- [ ] sharkjack
	- [x] curl
- [ ] Network Layout
	- [ ] devices
	- [ ] ports
		- [ ] 22 - ssh
		- [ ] 21 - ftp
- [ ] payload
	- network scan [NMAP]
	- 
	- discord webhook
- [ ] target
	- contact information

## Resources:
- [YouTube Video]()
- [YouTube Channel](https://youtube.com/cosmodiumcs)
- [Website](https://cosmodiumcs.com)

## Requirements:
- [SharkJack](https://shop.hak5.org/products/shark-jack?variant=21284894670961)

## Download:
```bash
svn checkout https://github.com/CosmodiumCS/payloads/trunk/sharkjack/tremor
```

## Instructions:


## Extraneous:
- [pipedream](https://pipedream.com/)
#projects #hardware #malware  