function cookie {
write-host "Cooookies" -foregroundcolor 'green'
calc
}
