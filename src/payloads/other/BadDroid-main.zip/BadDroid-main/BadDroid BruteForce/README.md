# Pin List NOT made by me re-edited for the flipper zero Original by Urbanadventurer
