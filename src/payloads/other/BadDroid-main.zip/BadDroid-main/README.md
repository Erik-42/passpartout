# BadDroid
Fun BadUSB scripts for Android! Tested with BadKB Made for the Flipper Zero!

# Tested on: Motorola PURE And Galaxy Note 20
"REMINDER THESE MAY NOT FULLY WORK FOR YOUR ANDROID OR DEVICE MODEL" and such, they should still atleast do the actions
ㅤㅤ

Custom script TOOLs for Android, instead of those basic scripts.
with some of these scripts you can do more fun control for Android.


such as :
ㅤ

The "Caught in 480p" Script

Description : 

https://user-images.githubusercontent.com/114778067/225493247-97df6960-d014-44c8-9b75-7443b74b1ba0.mp4

ㅤ

The "Gmail AutoFiller" Script

Description :

https://user-images.githubusercontent.com/114778067/225505713-f8e2b38f-8b4c-4833-90a9-c76fa5331933.mp4






ㅤ

The "Not MY TABS" Script

Description : DELTES 100+ TABS USE WISELY 


ㅤ

The "Tab Flooder" Script

Description :

https://user-images.githubusercontent.com/114778067/225382422-b667f7d1-7ac5-4e30-9d84-974e019f7648.mp4


ㅤ

The "Text Someone" Script

Description : 

https://user-images.githubusercontent.com/114778067/225381493-ca325458-4803-4ddb-a8b6-2c89360c4f55.mp4


ㅤㅤ

The "Tab Viewer" Script

Description : 

https://user-images.githubusercontent.com/114778067/225416293-278149e7-5f2f-40e0-9d8f-915c45445c1e.mp4





(REMINDER THESE ARE NOT PERFECT SCRIPTS MAY NEED TO REDO SOME FOR THEM TO WORK)


# This is not all the scripts READ the scripts code, made for modifications of your liking

ㅤ

If YOU make something cool with the custom Scripts from BadDroid id like to see some, cause I would love to add more BadDroid scripts based off the Flipper Community! 
if you want my discord is "wiskey#0708"
Im also on the offical FlipperZero Discord server where if you want id like to see some.

