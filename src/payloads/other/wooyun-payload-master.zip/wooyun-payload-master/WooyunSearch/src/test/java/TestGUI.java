import wooyun.GUI;

public class TestGUI {
    public static void main(String[] args) {
//        GUI g = new GUI("test!");
    }
}
