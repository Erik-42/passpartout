## About:
* Title: keyboard_hangover
* Description: keyboard_hangover is a powerful oneliner payload which randomly remaps target's keyboard.
* AUTHOR: drapl0n
* Version: 1.0
* Category: Execution.
* Target: Unix-like operating systems.
* Attackmodes: HID.

## keyboard_hangover: keyboard_hangover is a powerful oneliner payload which randomly remaps target's keyboard and and auto-triggers it.

### Features:
1. Randomly remaps keyboard.
2. Auto-Triggers on shell execution.
3. Persistent payload.
4. Fast execution.
5. Oneliner.

### Workflow:
1. Prevent storing history.
2. Creating random string generation mechanism.
3. Creating loop to find files.
4. Granting executing privileges.
5. Executing Payload Script.

#### Support me if you like my work:
* https://twitter.com/drapl0n 
