## About
# Title: capslock_disable
# Description: capslock_disable disables capslock on target's system.
# AUTHOR: drapl0n
# Version: 1.0
# Category: Execution
# Target: GNU/Linux.
# Attackmodes: HID.

## capslock_disable: capslock_disable disables capslock on target's system. Can be used as module to craft payloads which requires long time to execute.

### Workflow:
1. Executing Terminal Emulator.
2. Prevent storing history.
3. Executing command which disables capslock.
4. Terminating terminal instance.

#### Support me if you like my work:
* https://twitter.com/drapl0n 
