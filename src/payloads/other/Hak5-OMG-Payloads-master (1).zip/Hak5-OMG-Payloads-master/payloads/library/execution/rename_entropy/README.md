## About:
* Title: rename_entropy
* Description: rename_entropy is a powerful payload which renames target files along with extensions in home directory.
* AUTHOR: drapl0n
* Version: 1.0
* Category: Execution.
* Target: Unix-like operating systems.
* Attackmodes: HID.

## rename_entropy: rename_entropy is a powerful payload which renames target files along with extensions in home directory.

### Features:
1. Renames files and directories.
2. Fast paylaod execution.
3. Oneliner Payload.

### Workflow:
1. Prevent storing history.
2. Creating random string generation mechanism.
3. Granting executing privileges.
4. Executing Payload Script.

#### Support me if you like my work:
* https://twitter.com/drapl0n 
