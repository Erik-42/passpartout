# Bouncy Coil
- Author: Cribbit
- Version: 1.0
- Target: Windows (Powershell 5.1+)
- Category: General

## Change Log
| Version | Changes         |
| ------- | --------------- |
| 1.0     | Initial release |

## Description
Uses Powershell to create a O.MG Coil that bounces around the screen.

![Demo](OMGCoil.gif)