mkdir ~/.config/OMGNet
mv payload ~/.config/OMGNet/
touch ~/.config/OMGNet/OMGNet.db 
chmod +x OMGNetManager
sudo mv OMGNetManager /bin/
