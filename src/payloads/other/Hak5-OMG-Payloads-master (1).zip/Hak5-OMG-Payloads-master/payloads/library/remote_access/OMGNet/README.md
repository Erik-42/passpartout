# OMGNet

## About:
* Title: OMGNet
* Description: Create, Encode, Inject, Spread your OMGNet and manage it using OMGNetManager.
* AUTHOR: drapl0n
* Version: 1.0
* Category: Remote Access
* Target: Unix-like operating systems with systemd.
* Attackmodes: HID

## OMGNet is cluster of systems infected with persistentReverseOMG which are manged by OMGNetManager.

### Functions:
* Connect to target.
* Create new target.
* List targets.
* Remove target.
* Update target.

### Installation:
Use ``install.sh`` script to install OMGNetManager.

### Usage:
Use command ``OMGNetManager``.

#### Support me if you like my work:
* https://twitter.com/drapl0n
