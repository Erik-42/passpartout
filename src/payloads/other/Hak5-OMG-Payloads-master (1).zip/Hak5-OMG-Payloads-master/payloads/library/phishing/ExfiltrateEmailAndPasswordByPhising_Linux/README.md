 
# Exfiltrate Email And Password By Phising - Linux ✅

A script used to exfiltrate the email and the email password by a popup (KDE/kdialog based) phishing based on linux systems.

**Category**: Phishing, Credentials

## Description

A script used to exfiltrate the email and the email password by a popup (KDE/kdialog based) phishing based on linux systems.

Opens a shell, get the email and the email password by a popup, send the input to a Discord webhook.

## Getting Started

### Dependencies

* Internet Connection
* Discord webhook
* KDE/kdialog based

### Settings

* Set the Discord webhook

## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/github.png?raw=true width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/linkedin.png?raw=true width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>