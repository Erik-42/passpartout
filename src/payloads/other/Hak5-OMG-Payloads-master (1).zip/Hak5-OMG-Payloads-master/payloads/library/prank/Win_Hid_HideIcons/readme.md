# Hide desktop icons
* Author: Cribbit 
* Version: 1.0
* Tested on: Windows 10
* Category: pranks

## Change Log
| Version | Changes                       |
| ------- | ------------------------------|
| 1.0     | Initial release               |

## Description
Right clicks on the desktop and navigates the menu to hide the desktop icons.
