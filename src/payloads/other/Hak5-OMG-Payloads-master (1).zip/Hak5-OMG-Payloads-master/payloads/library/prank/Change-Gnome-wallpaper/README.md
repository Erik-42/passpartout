# Change Gnome wallpaper

A payload for changing the targets wallpaper on Gnome
**Category:** Prank

## Dependencies
- Linux Gnome
- Internet connection

## Settings
- `DUCKY_LANG` make sure to chose your targets keyboard layout
- `#LINK` the image url of the wallpaper to set (by default its [this](https://pbs.twimg.com/tweet_video_thumb/GLJE0kIWkAE_ohg.jpg))
