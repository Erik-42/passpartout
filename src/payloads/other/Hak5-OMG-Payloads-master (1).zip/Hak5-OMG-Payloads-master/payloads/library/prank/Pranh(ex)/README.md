# Pranh(ex)

This script is named Prenh(ex) because it is the union between **Prank**, the payload section of Hak5, and hex which represents the heart of the payload itself since it is installed following a conversion to **hexadecimal**. This script also contains a Time-Based **Easter Egg** so if you want to enjoy the joke don't read the code and wait a few seconds. ^^

Executables have been removed for security reasons.

**Category**: Prank

![](assets/1.gif)

## Description

This script is named Prenh(ex) because it is the union between Prank, the payload section of Hak5, and hex which represents the heart of the payload itself since it is installed following a conversion to hexadecimal. This script also contains a Time-Based Easter Egg so if you want to enjoy the joke don't read the code and wait a few seconds. ^^

Installing and running executables on machines without explicit owner authorization can **lead to significant damage** both to the **machine** and **legal repercussions** for those who choose to do so. It is crucial to respect ownership rights and seek proper authorization to ensure the security and integrity of the system while staying within the boundaries of the law.

## Dependencies

* **Nothing** (i know, it's absurd)

## Note

- For the creation of the executable, the hexadecimal code and in general to create this program I stuck to the payload: `Install And Run Any Arbitrary Executable - No Internet And Root Needed`
- Tested on `Windows 11`
- Running checked but not blocked by Avast antivirus
- Original Python code in `assets/pranh(ex).py`
- Hex content in `assets/hexfile.txt`
- exe file in `assets/pranh(ex).exe`

## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/github.png?raw=true width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.instagram.com/alessandro_greco_aka_aleff/">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/instagram.png?raw=true width="48" height="48" />
      </a>
      <br>Instagram
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/linkedin.png?raw=true width="48" height="48" />
      </a>
      <br>Discord
    </td>
  </tr>
</table>
</div>
