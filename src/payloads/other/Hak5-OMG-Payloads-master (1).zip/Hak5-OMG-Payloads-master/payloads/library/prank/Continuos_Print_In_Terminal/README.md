# Continuos Print In Terminal

Plug And Play

A script used to prank your friends with a terminal print.

**Category**: Prank

## Description

A script used to prank your friends with a terminal print.

Open a PowerShell, download the Python script and execute it. The Python script will print in output (everytime with a different color) the phrase "Your computer is infected!".

## Getting Started

### Dependencies

* Internet Connection
* ExecutionPolicy Bypass
* Python

## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/github.png?raw=true width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/linkedin.png?raw=true width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>