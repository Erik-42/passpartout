# Try To Catch Me

A script used to prank your friends with a script that will create a TryToCatchMe popup uncatchable.

**Category**: Prank

![](example.gif)

## Description

A script used to prank your friends with a script that will create a TryToCatchMe popup uncatchable.

Open a PowerShell, download the Python script and execute it. The Python script will create the popup through the Tk Popup.

## Getting Started

## Dependencies

* Internet Connection

## Settings

- Setup your Python script link

    `DEFINE SCRIPT-PY-LINK example.com`

## Credits

<h2 align="center"> Aleff :octocat: </h2>
<div align=center>
<table>
  <tr>
    <td align="center" width="96">
      <a href="https://github.com/aleff-github">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/github.png?raw=true width="48" height="48" />
      </a>
      <br>Github
    </td>
    <td align="center" width="96">
      <a href="https://www.linkedin.com/in/alessandro-greco-aka-aleff/">
        <img src=https://github.com/aleff-github/aleff-github/blob/main/img/linkedin.png?raw=true width="48" height="48" />
      </a>
      <br>Linkedin
    </td>
  </tr>
</table>
</div>