package jmg.cli;

public class CLIApp {
    public static void main(String[] args) throws Throwable {
        Console console = new Console();
        console.init();
        console.run();
    }
}
