package org.springframework.web.servlet;

public interface AsyncHandlerInterceptor {
}
