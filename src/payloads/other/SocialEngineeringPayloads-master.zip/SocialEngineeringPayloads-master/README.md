### SocialEngineeringPayloads

This is a collection of social engineering tricks and payloads being used for credential theft and spear phishing attacks.

NOTE: Most of these payloads are PoC to execute calc.exe

### Disclaimer

These details/samples are for Educational purpose ONLY. Do not use it without permission. The usual disclaimer applies, especially the fact that me (bhdresh) is not liable for any damages caused by direct or indirect use of the information or functionality provided by these programs. The author or any Internet provider bears NO responsibility for content or misuse of these programs or any derivatives thereof. By using these details/samples you accept the fact that any damage (dataloss, system crash, system compromise, etc.) caused by the use of these is not bhdresh's responsibility.

Finally, this is a personal development, please respect its philosophy and don't use it for bad things!

### Licence
CC BY 4.0 licence - https://creativecommons.org/licenses/by/4.0/
