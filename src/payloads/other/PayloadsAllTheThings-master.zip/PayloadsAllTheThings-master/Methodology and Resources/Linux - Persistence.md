# Linux - Persistence

:warning: Content of this page has been moved to [InternalAllTheThings/redteam/persistence/linux-persistence](https://swisskyrepo.github.io/InternalAllTheThings/redteam/persistence/linux-persistence/)

- [Basic reverse shell](https://swisskyrepo.github.io/InternalAllTheThings/redteam/persistence/linux-persistence/#basic-reverse-shell)
- [Add a root user](https://swisskyrepo.github.io/InternalAllTheThings/redteam/persistence/linux-persistence/#add-a-root-user)
- [Suid Binary](https://swisskyrepo.github.io/InternalAllTheThings/redteam/persistence/linux-persistence/#suid-binary)
- [Crontab - Reverse shell](https://swisskyrepo.github.io/InternalAllTheThings/redteam/persistence/linux-persistence/#crontab---reverse-shell)
- [Backdooring a user's bash_rc](https://swisskyrepo.github.io/InternalAllTheThings/redteam/persistence/linux-persistence/#backdooring-a-users-bash_rc)
- [Backdooring a startup service](https://swisskyrepo.github.io/InternalAllTheThings/redteam/persistence/linux-persistence/#backdooring-a-startup-service)
- [Backdooring a user startup file](https://swisskyrepo.github.io/InternalAllTheThings/redteam/persistence/linux-persistence/#backdooring-a-user-startup-file)
- [Backdooring Message of the Day](https://swisskyrepo.github.io/InternalAllTheThings/redteam/persistence/linux-persistence/#backdooring-message-of-the-day)
- [Backdooring a driver](https://swisskyrepo.github.io/InternalAllTheThings/redteam/persistence/linux-persistence/#backdooring-a-driver)
- [Backdooring the APT](https://swisskyrepo.github.io/InternalAllTheThings/redteam/persistence/linux-persistence/#backdooring-the-apt)
- [Backdooring the SSH](https://swisskyrepo.github.io/InternalAllTheThings/redteam/persistence/linux-persistence/#backdooring-the-ssh)
- [Backdooring Git](https://swisskyrepo.github.io/InternalAllTheThings/redteam/persistence/linux-persistence/#backdooring-git)
- [Additional Linux Persistence Options](https://swisskyrepo.github.io/InternalAllTheThings/redteam/persistence/linux-persistence/#additional-persistence-options)
- [References](https://swisskyrepo.github.io/InternalAllTheThings/redteam/persistence/linux-persistence/#references)