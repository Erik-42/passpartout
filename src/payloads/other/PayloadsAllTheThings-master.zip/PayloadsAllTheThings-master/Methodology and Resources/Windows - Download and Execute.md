# Windows - Download and execute methods

:warning: Content of this page has been moved to [InternalAllTheThings/redteam/access/windows-download-execute](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/windows-download-execute/)

- [Downloaded files location](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/windows-download-execute/#downloaded-files-location)
- [Powershell](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/windows-download-execute/#powershell)
- [Cmd](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/windows-download-execute/#cmd)
- [Cscript / Wscript](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/windows-download-execute/#cscript-wscript)
- [Mshta](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/windows-download-execute/#mshta)
- [Rundll32](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/windows-download-execute/#rundll32)
- [Regasm / Regsvc](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/windows-download-execute/#regasm-regsvc-subtee)
- [Regsvr32](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/windows-download-execute/#regsvr32)
- [Odbcconf](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/windows-download-execute/#odbcconf)
- [Msbuild](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/windows-download-execute/#msbuild)
- [Certutil](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/windows-download-execute/#certutil)
- [Bitsadmin](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/windows-download-execute/#bitsadmin)
- [References](https://swisskyrepo.github.io/InternalAllTheThings/redteam/access/windows-download-execute/#references)