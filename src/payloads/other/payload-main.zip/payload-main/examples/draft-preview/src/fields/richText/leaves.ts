import type { RichTextLeaf } from '@payloadcms/richtext-slate'

const defaultLeaves: RichTextLeaf[] = ['bold', 'italic', 'underline']

export default defaultLeaves
