import { TenantFieldComponent as TenantFieldComponent_0e322269e5426a9b98ca88b6faa9d3d0 } from '@/fields/TenantField/components/Field'
import { TenantSelectorRSC as TenantSelectorRSC_9d7720c4b50db35595dfefa592fabd33 } from '@/components/TenantSelector'

export const importMap = {
  '@/fields/TenantField/components/Field#TenantFieldComponent':
    TenantFieldComponent_0e322269e5426a9b98ca88b6faa9d3d0,
  '@/components/TenantSelector#TenantSelectorRSC':
    TenantSelectorRSC_9d7720c4b50db35595dfefa592fabd33,
}
