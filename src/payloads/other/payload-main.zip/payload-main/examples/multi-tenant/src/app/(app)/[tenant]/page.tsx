import Page from './[...slug]/page'

export default Page
