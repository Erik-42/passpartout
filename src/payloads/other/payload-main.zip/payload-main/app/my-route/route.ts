export const GET = () => {
  return Response.json({
    hello: 'elliot',
  })
}
