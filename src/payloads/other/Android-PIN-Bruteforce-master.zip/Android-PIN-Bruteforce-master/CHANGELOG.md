Version 0.2 - June, 2022 (In progress)
- Added CHANGELOG
- Added Troubleshooting guide

Version 0.1 - Development

