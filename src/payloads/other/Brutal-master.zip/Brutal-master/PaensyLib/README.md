#Getting Started With Paensy

You will need the Teensy USB Development Board and Teensyduino. The PJRC website has a very easy to use guide on getting Teensyduino setup.

Once Teensyduino is installed and working, place the PaensyLib folder inside your Arduino\libraries. Arduino is installed in your Program Files (x86 if 64 bit) directory by default. To utilize Paensy, simply include the library in your code:

include <paensy.h>
