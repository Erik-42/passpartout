
# Now Teensy can be use for penetration 
Teensy like a rubber ducky , why im choose teensy ? because the price very cheap for me . t’s extremely useful for executing scripts on a target machine without the need for human-to-keyboard interaction ( HID -ATTACK ) .When you insert the device, it will be detected as a keyboard, and using the microprocessor and onboard flash memory storage, you can send a very fast set of keystrokes to the target’s machine and completely compromise it, regardless of autorun. I’ve used it in my security testing to run recon or enumeration scripts, execute reverse shells, exploit local DLL hijack/privilege escalation vulnerabilities, and get all password . 
Now im develop new tools the name is  Brutal 

# Brutal

Brutal is a toolkit to quickly create various payload,powershell attack , virus attack and launch listener for a Human Interface Device

[![Version](https://img.shields.io/badge/Brutal-1.0.0-brightgreen.svg?maxAge=259200)]()
[![Version](https://img.shields.io/badge/Codename-Reaper-red.svg?maxAge=259200)]()
[![Stage](https://img.shields.io/badge/Release-Stable-brightgreen.svg)]()
[![Build](https://img.shields.io/badge/Supported_OS-Linux-orange.svg)]()

<img src="https://cloud.githubusercontent.com/assets/17976841/20054455/a43d8358-a50f-11e6-90a6-c967a9d3a43f.png" width="60%"></img> 


### Donate
- If this project very help you to penetration testing  and u want support me , you can give me a cup of coffee :)
- [![Donation](https://img.shields.io/badge/bitcoin-donate-yellow.svg)](https://blockchain.info/id/address/1NuNTXo7Aato7XguFkvwYnTAFV2immXmjS)


## Screenshoot
<img src="https://cloud.githubusercontent.com/assets/17976841/20054499/bc2d91ec-a50f-11e6-8a2a-eb9aa029e40b.png" width="32%"></img> 
<img src="https://cloud.githubusercontent.com/assets/17976841/20054497/bc2affe0-a50f-11e6-99cb-81a1de0df249.png" width="32%"></img> 
<img src="https://cloud.githubusercontent.com/assets/17976841/20054498/bc2b6f2a-a50f-11e6-9b7f-414f23508819.png" width="32%"></img> 

## Video 

- Check this video https://www.youtube.com/watch?v=WaqY-pQpuV0

- Do you want like a mr robot hacking scene when Angela moss plug usb into computer for get  credential information ? you can choose payload in brutal ( optional 3 or 4 )

## The Goal 

- Generate  various payload and powershell attack without coding 

- To help breaking computer very fast and agile :p

- The Payloads Compatibility > target Windows machines only


## Requirements

- Arduino Software ( I used v1.6.7 )

- TeensyDuino 

- Linux udev rules 

- How install all requirements ? [Visit This Wiki](https://github.com/Screetsec/Brutal/wiki/Install-Requirements)

## Supported Hardware

The following hardware has been tested and is known to work.

- Teensy 3.x 

- Usb Cable


## :scroll: Changelog
Be sure to check out the [Changelog] and Read CHANGELOG.md


## Getting Started
1. ```Copy and paste the PaensyLib folder inside your Arduino\libraries```
1. ```git clone https://github.com/Screetsec/Brutal.git```
2. ```cd Brutal```
3. ```chmod +x Brutal.sh ```
3. ```sudo ./Brutal.sh or sudo su ./Brutal.sh ```


## BUG ? 
- Submit new issue 
- Contact me 
- Hey sup ? do you want ask about all my tools ? you can join me in telegram.me/offscreetsec

## Donations 

- Donation: Send to [bitcoin](https://blockchain.info/id/address/1NuNTXo7Aato7XguFkvwYnTAFV2immXmjS)

- Addres Bitcoin : 1NuNTXo7Aato7XguFkvwYnTAFV2immXmjS

- <img src="https://cloud.githubusercontent.com/assets/17976841/25007109/75380fa6-2089-11e7-8a4a-4a8ae9c06e24.png" width="30%"></img>


## :octocat: Credits

- Thanks to allah and Screetsec [ Edo -maland- ] <Me> 
- Dracos Linux from Scratch Indonesia ( Awesome Penetration os ), you can see in http://dracos-linux.org/ 
- Offensive Security for the awesome OS ( http://www.offensive-security.com/ )
- http://www.kali.org/
- Jack Wilder admin in http://www.linuxsec.org
- And another open sources tool in github
- Uptodate new tools hacking visit http://www.kitploit.com

## Disclaimer

***Note: modifications, changes, or alterations to this sourcecode is acceptable, however,any public releases utilizing this code must be approved by writen this tool ( Edo -m- ).***



 

