AutomatorApplet.icns goes into /Applications/Payload-Free Package Creator.app/Contents/Resources/ when you build a new version of Payload-Free Package Creator.
